import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Mail, Linkedin, Github } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      {/* Cover */}
      <section className="h-screen flex flex-col items-center justify-center bg-gradient-to-r from-indigo-200 to-blue-100">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-5xl font-bold mb-4"
        >
          Aya Mohamed
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-xl"
        >
          Data Analyst | Business Information Systems
        </motion.p>
        <p className="mt-2 italic">Turning data into actionable insights</p>
      </section>

      {/* About */}
      <section className="py-16 px-6 max-w-4xl mx-auto">
        <h2 className="text-3xl font-semibold mb-6">About Me</h2>
        <p className="mb-4">
          I’m a Business Information Systems student passionate about data
          analysis. Skilled in SQL, Excel, and Power BI, I help businesses make
          data-driven decisions.
        </p>
        <ul className="list-disc pl-6">
          <li>SQL, Excel, Power BI, Python</li>
          <li>Data Cleaning & Visualization</li>
          <li>Reporting & Dashboards</li>
        </ul>
      </section>

      {/* Projects */}
      <section className="py-16 px-6 bg-white">
        <h2 className="text-3xl font-semibold mb-10 text-center">Projects</h2>
        <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          <Card className="shadow-md">
            <CardContent className="p-6">
              <h3 className="text-xl font-bold mb-2">E-commerce Sales Dashboard</h3>
              <p className="text-sm mb-2">Power BI</p>
              <p className="text-gray-700">
                Increased sales by identifying top categories.
              </p>
            </CardContent>
          </Card>
          <Card className="shadow-md">
            <CardContent className="p-6">
              <h3 className="text-xl font-bold mb-2">SQL Data Cleaning</h3>
              <p className="text-sm mb-2">Olist Dataset</p>
              <p className="text-gray-700">
                Improved query performance & accuracy.
              </p>
            </CardContent>
          </Card>
          <Card className="shadow-md">
            <CardContent className="p-6">
              <h3 className="text-xl font-bold mb-2">Netflix Data Analysis</h3>
              <p className="text-sm mb-2">Python</p>
              <p className="text-gray-700">
                Visualized most popular genres & ratings.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 px-6 text-center bg-gradient-to-r from-blue-100 to-indigo-200">
        <h2 className="text-3xl font-semibold mb-6">Let’s Work Together!</h2>
        <p className="mb-8">
          Let’s turn your data into insights that drive growth!
        </p>
        <div className="flex justify-center gap-6">
          <Button variant="outline" asChild>
            <a href="mailto:yourmail@example.com" className="flex items-center gap-2">
              <Mail className="w-4 h-4" /> Email
            </a>
          </Button>
          <Button variant="outline" asChild>
            <a href="https://linkedin.com/in/aya-mohamed" target="_blank" className="flex items-center gap-2">
              <Linkedin className="w-4 h-4" /> LinkedIn
            </a>
          </Button>
          <Button variant="outline" asChild>
            <a href="https://github.com/aya-mohamed" target="_blank" className="flex items-center gap-2">
              <Github className="w-4 h-4" /> GitHub
            </a>
          </Button>
        </div>
      </section>
    </div>
  );
}